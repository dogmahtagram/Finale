﻿using System;

namespace MSCommon
{
	public enum MasterServerMessageType
	{
		RegisterHost,
		RequestHostList,
		RequestIntroduction,
	}
}
